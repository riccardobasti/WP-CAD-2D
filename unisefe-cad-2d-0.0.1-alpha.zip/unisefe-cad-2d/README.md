# UNISEFE CAD 2D — WordPress Plugin

Versione plugin: **0.0.1 Alpha**  
Motore CAD incluso: **UNISEFE CAD 2D v0.0.6 Alpha**

Il plugin mantiene il CAD HTML originale come applicazione autonoma e lo incorpora in WordPress senza modificarne il motore.

## Installazione

1. Carica `unisefe-cad-2d-0.0.1-alpha.zip` da **Plugin → Aggiungi plugin → Carica plugin**.
2. Attiva **UNISEFE CAD 2D**.
3. Inserisci in una pagina:

```text
[unisefe_cad_2d]
```

È disponibile anche l'alias:

```text
[riki_cad_2d]
```

## Altezza

```text
[unisefe_cad_2d height="900px"]
```

Oppure, ad esempio:

```text
[unisefe_cad_2d height="85vh"]
```

## Principio di integrazione

WordPress gestisce soltanto il contenitore. Il CAD resta nel file HTML originale dentro `app/unisefe-cad-2d.html`, isolato dal CSS e dal JavaScript del tema e degli altri plugin.

## Licenza

MIT
