<?php
/**
 * Plugin Name: UNISEFE CAD 2D
 * Plugin URI: https://italfaber.com/
 * Description: CAD 2D autonomo UNISEFE/RIKI integrabile in WordPress tramite shortcode.
 * Version: 0.0.1-alpha
 * Author: ITALFABER
 * License: MIT
 * Text Domain: unisefe-cad-2d
 */

if (!defined('ABSPATH')) {
    exit;
}

final class UNISEFE_CAD_2D_Plugin {
    const VERSION = '0.0.1-alpha';

    public static function init() {
        add_shortcode('unisefe_cad_2d', array(__CLASS__, 'shortcode'));
        add_shortcode('riki_cad_2d', array(__CLASS__, 'shortcode'));
    }

    public static function shortcode($atts = array()) {
        $atts = shortcode_atts(
            array(
                'height' => '780px',
                'title'  => 'UNISEFE CAD 2D',
            ),
            $atts,
            'unisefe_cad_2d'
        );

        $height = self::sanitize_height($atts['height']);
        $title  = sanitize_text_field($atts['title']);
        $src    = plugins_url('app/unisefe-cad-2d.html', __FILE__);
        $id     = wp_unique_id('unisefe-cad-2d-');

        ob_start();
        ?>
        <div class="unisefe-cad-2d-wrap" id="<?php echo esc_attr($id); ?>" style="width:100%;max-width:none;margin:0;padding:0;">
            <iframe
                src="<?php echo esc_url($src); ?>"
                title="<?php echo esc_attr($title); ?>"
                loading="eager"
                allowfullscreen
                style="display:block;width:100%;height:<?php echo esc_attr($height); ?>;border:0;margin:0;padding:0;background:#fff;"
            ></iframe>
        </div>
        <?php
        return ob_get_clean();
    }

    private static function sanitize_height($height) {
        $height = trim((string) $height);
        if (preg_match('/^\d+(?:\.\d+)?(?:px|vh|dvh|svh|lvh|rem|em|%)$/i', $height)) {
            return $height;
        }
        return '780px';
    }
}

UNISEFE_CAD_2D_Plugin::init();
